<h1>Disclaimer</h1>
<h6>This is only a rough plan for future videos and it's in no particular order but feel free to ask for more information or suggest any tutorials you would like</h6>

OpenGL Maths<br />

Translation<br />
Rotation<br />
Scaling<br />


Texturing using SOIL<br />
Normals<br />

Orphographic vs Perspective projection<br />

Frame rate<br />

Wireframe<br />

GLFW Prevent Resizing

Lighting<br />

Skybox<br />

Text<br />

Particles<br />

Collision<br />

Raycasting<br />

Anti-aliasing<br />

Tesselation<br />

Height maps<br />

Custom water system<br />
Model loader<br />

Ping pong game tutorial in OpenGL/GLHelper<br />   
OpenGL Solar System with realistic/variable day cycle<br />
